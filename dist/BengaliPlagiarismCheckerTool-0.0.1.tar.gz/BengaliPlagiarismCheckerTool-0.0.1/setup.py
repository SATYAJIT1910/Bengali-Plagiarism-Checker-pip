import setuptools

setuptools.setup(
    package_data={'BengaliPlagiarismChecker': ['corpus.db']},
    zip_safe=False
)